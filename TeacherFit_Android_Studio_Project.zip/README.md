# TeacherFit

Native Android starter application for male teachers to plan professional outfits.

## Technology
- Kotlin
- Jetpack Compose / Material 3
- MVVM foundation
- Outfit compatibility engine
- Visual colour palette
- Ready for Room integration

## Open in Android Studio
1. Open the `TeacherFit` folder.
2. Let Android Studio sync Gradle.
3. Run on an Android 8.0+ device/emulator.
4. Build > Generate App Bundles or APKs > Generate APKs.

## Notes
The current UI keeps wardrobe state in the ViewModel for a simple first build. The project includes Room dependencies and entity/DAO definitions; wiring Room persistence into the repository is the next production-hardening step.
