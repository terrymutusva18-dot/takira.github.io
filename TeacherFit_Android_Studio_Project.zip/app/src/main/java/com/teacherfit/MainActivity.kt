package com.teacherfit

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.*
import androidx.room.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

enum class ClothingCategory(val label: String) {
    SHIRT("Shirts"), TROUSER("Trousers"), BLAZER("Blazers"), SHOE("Shoes"), TIE("Ties")
}

data class ClothingItem(
    val id: Long = 0,
    val category: ClothingCategory,
    val colorName: String,
    val colorHex: String
)

@Entity(tableName = "clothing_items")
data class ClothingItemEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val category: String,
    val colorName: String,
    val colorHex: String,
    val createdAt: Long = System.currentTimeMillis()
)

@Dao
interface ClothingDao {
    @Query("SELECT * FROM clothing_items ORDER BY category, createdAt DESC")
    fun observeAll(): Flow<List<ClothingItemEntity>>
    @Insert suspend fun insert(item: ClothingItemEntity)
    @Delete suspend fun delete(item: ClothingItemEntity)
    @Query("DELETE FROM clothing_items") suspend fun deleteAll()
}

@Database(entities = [ClothingItemEntity::class], version = 1, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun clothingDao(): ClothingDao
}

enum class WardrobeColor(val display: String, val hex: String) {
    WHITE("White","#FFFFFF"), LIGHT_BLUE("Light Blue","#ADD8E6"), BLUE("Blue","#2563EB"),
    NAVY("Navy","#172554"), BLACK("Black","#111111"), GREY("Grey","#6B7280"),
    CHARCOAL("Charcoal","#374151"), BEIGE("Beige","#D6C6A8"), KHAKI("Khaki","#C3B091"),
    BROWN("Brown","#795548"), TAN("Tan","#C19A6B"), BURGUNDY("Burgundy","#800020"),
    MAROON("Maroon","#7F1D1D"), PINK("Pink","#F4A7B9"), GREEN("Green","#2F6B3C"),
    OLIVE("Olive","#65743A"), PURPLE("Purple","#6B4C9A"), YELLOW("Yellow","#EAB308")
}

data class Outfit(
    val shirt: ClothingItem,
    val trousers: ClothingItem,
    val blazer: ClothingItem?,
    val shoes: ClothingItem,
    val tieSuggestions: List<String>
)

class OutfitGenerator {
    fun generate(items: List<ClothingItem>): Outfit? {
        val shirts = items.filter { it.category == ClothingCategory.SHIRT }
        val trousers = items.filter { it.category == ClothingCategory.TROUSER }
        val blazers = items.filter { it.category == ClothingCategory.BLAZER }
        val shoes = items.filter { it.category == ClothingCategory.SHOE }
        if (shirts.isEmpty() || trousers.isEmpty() || shoes.isEmpty()) return null

        data class S(val s: ClothingItem,val t: ClothingItem,val b: ClothingItem?,val sh: ClothingItem,val score:Int)
        val list = mutableListOf<S>()
        for (s in shirts) for (t in trousers) {
            val ts = trouserScore(s.colorName,t.colorName); if (ts <= 0) continue
            for (sh in shoes) {
                val ss = shoeScore(t.colorName,sh.colorName); if (ss <= 0) continue
                if (blazers.isEmpty()) list += S(s,t,null,sh,ts+ss)
                else for (b in blazers) {
                    val bs = blazerScore(s.colorName,t.colorName,b.colorName)
                    if (bs > 0) list += S(s,t,b,sh,ts+ss+bs)
                }
            }
        }
        if (list.isEmpty()) return null
        val max = list.maxOf { it.score }
        val chosen = list.filter { it.score >= max - 2 }.random()
        return Outfit(chosen.s,chosen.t,chosen.b,chosen.sh,suggestTies(chosen.s.colorName,chosen.b?.colorName))
    }

    private fun trouserScore(s:String,t:String)=when(s) {
        "White" -> if(t in listOf("Navy","Charcoal","Grey","Black","Khaki","Beige","Brown")) 5 else 1
        "Light Blue" -> if(t in listOf("Navy","Charcoal","Grey","Khaki","Beige","Brown")) 5 else if(t=="Black") 4 else 0
        "Pink" -> if(t in listOf("Navy","Charcoal","Grey","Khaki","Beige")) 5 else 0
        "Blue" -> if(t in listOf("Navy","Grey","Charcoal","Khaki","Beige")) 5 else 0
        "Grey" -> if(t in listOf("Navy","Black","Charcoal")) 4 else 0
        else -> if(t in listOf("Navy","Grey","Charcoal","Black","Khaki","Beige")) 4 else 0
    }

    private fun blazerScore(s:String,t:String,b:String):Int {
        val score=when(b) {
            "Navy" -> if(s in listOf("White","Light Blue","Pink","Blue")) 5 else 2
            "Charcoal","Grey" -> if(s in listOf("White","Light Blue","Pink","Blue")) 5 else 2
            "Black" -> if(s in listOf("White","Light Blue","Pink","Grey")) 4 else 1
            "Brown","Tan","Beige" -> if(s in listOf("White","Light Blue","Pink","Blue")) 5 else 2
            "Burgundy","Maroon" -> if(s in listOf("White","Light Blue","Pink")) 4 else 0
            else -> 2
        }
        return if(score>0 && !(b==t && b !in listOf("Navy","Grey","Charcoal","Black"))) score else 0
    }

    private fun shoeScore(t:String,s:String)=when(s) {
        "Black" -> if(t in listOf("Black","Charcoal","Grey","Navy")) 5 else 2
        "Brown" -> if(t in listOf("Navy","Khaki","Beige","Brown","Tan","Grey")) 5 else 1
        "Tan" -> if(t in listOf("Navy","Khaki","Beige","Brown")) 5 else if(t=="Grey") 3 else 0
        else -> 1
    }

    private fun suggestTies(s:String,b:String?)=when(s) {
        "White" -> when(b) {"Navy"->listOf("Burgundy","Dark Blue");"Charcoal","Grey"->listOf("Burgundy","Navy");"Black"->listOf("Burgundy","Silver");else->listOf("Navy","Burgundy")}
        "Light Blue" -> when(b) {"Navy"->listOf("Burgundy","Deep Purple");"Grey","Charcoal"->listOf("Burgundy","Navy");"Brown","Tan"->listOf("Burgundy","Dark Brown");else->listOf("Burgundy","Navy")}
        "Pink" -> if(b=="Navy") listOf("Navy","Burgundy") else listOf("Navy","Dark Purple")
        "Blue" -> listOf("Burgundy","Dark Brown")
        "Grey" -> listOf("Burgundy","Navy")
        else -> listOf("Navy","Burgundy")
    }
}

class WardrobeViewModel : ViewModel() {
    private val generator = OutfitGenerator()
    var items by mutableStateOf(listOf<ClothingItem>()); private set
    var outfit by mutableStateOf<Outfit?>(null); private set

    fun add(category: ClothingCategory, color: WardrobeColor) {
        items = items + ClothingItem(items.size.toLong()+1,category,color.display,color.hex)
    }
    fun remove(id:Long) { items = items.filterNot { it.id==id } }
    fun generate() { outfit = generator.generate(items) }
}

@Composable fun TeacherFitTheme(content:@Composable ()->Unit) {
    MaterialTheme(colorScheme = lightColorScheme(
        primary=Color(0xFF23395D), secondary=Color(0xFF7657A8), background=Color(0xFFF8F7FC)
    ), content=content)
}

@Composable fun OutfitCard(title:String,item:ClothingItem) {
    val c=Color(android.graphics.Color.parseColor(item.colorHex))
    Card(Modifier.fillMaxWidth().padding(vertical=6.dp)) {
        Row(Modifier.padding(14.dp),verticalAlignment=Alignment.CenterVertically) {
            Box(Modifier.size(64.dp).clip(RoundedCornerShape(14.dp)).background(c)
                .border(1.dp,Color.Gray.copy(alpha=.25f),RoundedCornerShape(14.dp)))
            Spacer(Modifier.width(14.dp))
            Column { Text(title,fontWeight=FontWeight.Bold); Text(item.colorName,color=MaterialTheme.colorScheme.onSurfaceVariant) }
        }
    }
}

fun tieColor(n:String)=when(n) {
    "Burgundy"->Color(0xFF800020); "Navy","Dark Blue"->Color(0xFF172554)
    "Deep Purple","Dark Purple"->Color(0xFF4C1D95); "Silver"->Color(0xFF9CA3AF)
    "Dark Brown"->Color(0xFF4E342E); else->Color.Gray
}

@Composable fun OutfitScreen(vm:WardrobeViewModel) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp)) {
        Text("Today's Outfit",style=MaterialTheme.typography.headlineMedium,fontWeight=FontWeight.Bold)
        Text("Professional. Simple. Ready for school.",color=MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(18.dp))
        vm.outfit?.let { o ->
            OutfitCard("Shirt",o.shirt); OutfitCard("Trousers",o.trousers)
            o.blazer?.let { OutfitCard("Blazer",it) }; OutfitCard("Shoes",o.shoes)
            Card(Modifier.fillMaxWidth().padding(vertical=8.dp)) {
                Column(Modifier.padding(16.dp)) {
                    Text("Recommended Ties",fontWeight=FontWeight.Bold)
                    o.tieSuggestions.forEach { t -> Row(Modifier.padding(top=10.dp),verticalAlignment=Alignment.CenterVertically) {
                        Box(Modifier.size(28.dp).clip(CircleShape).background(tieColor(t))); Spacer(Modifier.width(10.dp)); Text(t)
                    }}
                }
            }
        } ?: Text("Add shirts, trousers and shoes, then generate your outfit.")
        Spacer(Modifier.height(12.dp))
        Button(onClick={vm.generate()},Modifier.fillMaxWidth().height(54.dp)) { Text("GENERATE OUTFIT") }
    }
}

@Composable fun InventoryScreen(vm:WardrobeViewModel) {
    var category by remember { mutableStateOf(ClothingCategory.SHIRT) }
    var color by remember { mutableStateOf(WardrobeColor.WHITE) }
    Column(Modifier.fillMaxSize().padding(18.dp)) {
        Text("My Wardrobe",style=MaterialTheme.typography.headlineMedium,fontWeight=FontWeight.Bold)
        Text("Add your clothes and build a reusable wardrobe.",color=MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(12.dp))
        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(6.dp)) {
            ClothingCategory.values().forEach { c ->
                FilterChip(selected=category==c,onClick={category=c},label={Text(c.label)})
            }
        }
        Spacer(Modifier.height(12.dp))
        Text("Choose colour",fontWeight=FontWeight.Bold)
        LazyVerticalGrid(columns=GridCells.Fixed(3),modifier=Modifier.height(190.dp),horizontalArrangement=Arrangement.spacedBy(8.dp),verticalArrangement=Arrangement.spacedBy(8.dp)) {
            items(WardrobeColor.values().toList()) { c ->
                val selected=color==c
                Row(Modifier.clip(RoundedCornerShape(12.dp)).background(MaterialTheme.colorScheme.surfaceVariant).clickable{color=c}.padding(8.dp),verticalAlignment=Alignment.CenterVertically) {
                    Box(Modifier.size(28.dp).clip(CircleShape).background(Color(android.graphics.Color.parseColor(c.hex))).border(1.dp,Color.Gray,CircleShape))
                    Spacer(Modifier.width(5.dp)); Text(c.display,style=MaterialTheme.typography.labelSmall)
                }
            }
        }
        Button(onClick={vm.add(category,color)},Modifier.fillMaxWidth()) { Text("ADD TO WARDROBE") }
        Spacer(Modifier.height(12.dp))
        Text("Saved Items",fontWeight=FontWeight.Bold)
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState())) {
            vm.items.forEach { i -> OutfitCard(i.category.label,i) }
        }
    }
}

@Composable fun App() {
    val vm:WardrobeViewModel=viewModel()
    val nav=rememberNavController()
    Scaffold(bottomBar={NavigationBar {
        NavigationBarItem(selected=nav.currentDestination?.route=="outfit",onClick={nav.navigate("outfit")},icon={},label={Text("Outfit")})
        NavigationBarItem(selected=nav.currentDestination?.route=="wardrobe",onClick={nav.navigate("wardrobe")},icon={},label={Text("Wardrobe")})
    }}) { p ->
        NavHost(nav,"outfit",Modifier.padding(p)) {
            composable("outfit"){OutfitScreen(vm)}
            composable("wardrobe"){InventoryScreen(vm)}
        }
    }
}

class MainActivity:ComponentActivity() {
    override fun onCreate(savedInstanceState:Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { TeacherFitTheme { App() } }
    }
}
